package com.serkanozcelik.mypurge.utils;

public class Constants {

    public static final String PREF_NAME = "pref_name", PREF_STORED = "pref_store",
            PREF_URL = "pref_url", PREF_DIRECTORY = "pref_direct";

}
